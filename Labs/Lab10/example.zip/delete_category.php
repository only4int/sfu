<?php
	if(isset($_GET['identity'])) {
		$identity = (int)$_GET['identity'];
		try {
			$pdo = new PDO('mysql:host=localhost;dbname=books', 'root', 'root', array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
			$count = $pdo->exec("DELETE FROM `category` WHERE `identity`=$identity");
			$pdo = NULL;
			if($count > 0) {
				header('Location: http://'.$_SERVER['HTTP_HOST'].'/categories.php');
			} else {
				header('Location: http://'.$_SERVER['HTTP_HOST'].'/error.php?message='.urlencode('С данной категорией связаны некоторые книги'));
			}
		} catch(PDOException $e) {
			header('Location: http://'.$_SERVER['HTTP_HOST'].'/error.php?message='.urlencode('Ошибка работы с базой данных'));
		}
	} else {
		header('Location: http://'.$_SERVER['HTTP_HOST'].'/error.php?message='.urlencode('Данные пропущены'));
	}
?>