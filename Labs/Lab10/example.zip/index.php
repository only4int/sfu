<?php
	try {
		/* выполняем подключение к серверу баз данных */
		$pdo = new PDO('mysql:host=localhost;dbname=books', 'root', 'root', array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
		/* выполняем SQL-запрос на извлечение всех книг из соответствующей таблицы (вместе с названиями категорий), рассчитываем общий рейтинг каждой книги */
		$result = $pdo->query('SELECT `book`.`identity`, `category`.`name`, `book`.`author`, `book`.`title`, `book`.`raiting`*`category`.`raiting` as total_raiting FROM `book` INNER JOIN `category` ON `book`.`category_identity`=`category`.`identity`');
		/* закрываем подключение с базой данных */
		$pdo = NULL;
	} catch(PDOException $e) {
		/* в случае возникновения ошибки работы с базой данных, просим пользователя перенаправить запрос к другой
		странице (error.php) */
		header('Location: http://'.$_SERVER['HTTP_HOST'].'/error.php?message='.urlencode('Ошибка работы с базой данных'));
	}
?>
<!-- формируем HTML-страницу со списком книг -->
<!DOCTYPE html>
<HTML>
	<HEAD>
		<META http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<TITLE>Список книг</TITLE>
		<LINK href="style.css" rel="stylesheet" type="text/css">
	</HEAD>
	<BODY>
		<H1>Список книг</H1>
		<MENU>
			<LI><STRONG>книги</STRONG></LI>
			<LI><A href="categories.php">категории</A></LI>
		</MENU>
		<HR>
		<TABLE>
			<TR>
				<TH>категория</TH>
				<TH>автор</TH>
				<TH>название</TH>
				<TH>общий рейтинг</TH>
				<TH>&nbsp;</TH>
			</TR>
			<?php
				/* перебираем все строки результата SQL-запроса */
				foreach($result as $row) {
					echo '<TR>';
					echo '<TD>'.$row['name'].'</TD>';
					echo '<TD>'.$row['author'].'</TD>';
					echo '<TD>'.$row['title'].'</TD>';
					echo '<TD>'.$row['total_raiting'].'</TD>';
					echo '<TD>';
					/* генерируем форму с кнопкой редактирования книги */
					echo '<FORM action="edit_book.php">';
					/* на форме редактирования при помощи скрытого элемента
					размещаем идентификатор редактируемой сущности */
					echo '<INPUT type="hidden" name="identity" value="'.$row['identity'].'">';
					echo '<DIV class="small"><BUTTON type="submit">&gt;&gt;</BUTTON></DIV>';
					echo '</FORM>';
					echo '</TD>';
					echo '</TR>';
				}
			?>
		</TABLE>
		<!-- создаём форму с кнопкой добавления новой книги, при этом PHP-скрипт
		для обработки этой формы тот же, что и для формы редактирования уже
		существующей книги (различаться эти ситуации будут по отсутствию или
		наличию идентификатора книги) -->
		<FORM class="main" action="edit_book.php">
			<DIV class="small"><BUTTON type="submit">+</BUTTON></DIV>
		</FORM>
	</BODY>
</HTML>
