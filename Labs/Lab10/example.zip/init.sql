/* удаляем базу данных и всё её содержимое, если такая база данных уже
существовала */
DROP DATABASE IF EXISTS `books`;

/* создаём базу данных с поддержкой по умолчанию кодировки UTF8 */
/* база данных будет содержать сведения о книгах, разбитых на категории,
и о рейтинге этих книг (и самих категорий) */
CREATE DATABASE `books` DEFAULT CHARACTER SET utf8;

/* делаем базу данных активной */
USE `books`;

/* создаём таблицу категорий */
CREATE TABLE `category` (
	/* первичный ключ с автоматически присваиваемым очередным номером */
	`identity` INTEGER PRIMARY KEY AUTO_INCREMENT,
	/* название категории */
	`name` VARCHAR(50) NOT NULL,
	/* рейтинг категории (среди других категорий) */
	`raiting` REAL NOT NULL CHECK (`raiting` BETWEEN 0 AND 1)
) DEFAULT CHARACTER SET utf8;

/* создаём таблицу книг */
CREATE TABLE `book` (
	/* первичный ключ с автоматически присваиваемым очередным номером */
	`identity` INTEGER PRIMARY KEY AUTO_INCREMENT,
	/* идентификатор категории, которой принадлежит книга */
	`category_identity` INTEGER NOT NULL,
	/* имя автора книги */
	`author` VARCHAR(100) NOT NULL,
	/* название книги */
	`title` VARCHAR(200) NOT NULL,
	/* рейтинг книги в пределах категории */
	`raiting` REAL NOT NULL CHECK (`raiting` BETWEEN 0 AND 1),
	/* внешний ключ, связывающий таблицу книг с таблицей категорий */
	FOREIGN KEY (`category_identity`) REFERENCES `category` (`identity`)
	/* при изменении в таблице категорий значений идентификаторов,
	соответствующие значения идентификаторов в таблице книг также будут
	изменены */
	ON UPDATE CASCADE
	/* удаление записей из таблицы категорий, для которых есть связанные записи
	в таблице книг, будет блокировано (запрещено) */
	ON DELETE RESTRICT
) DEFAULT CHARACTER SET utf8;
