<?php
	if(isset($_GET['identity'])) {
		$identity = (int)$_GET['identity'];
		try {
			$pdo = new PDO('mysql:host=localhost;dbname=books', 'root', 'root', array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
			$pdo->exec("DELETE FROM `book` WHERE `identity`=$identity");
			$pdo = NULL;
			header('Location: http://'.$_SERVER['HTTP_HOST'].'/index.php');
		} catch(PDOException $e) {
			header('Location: http://'.$_SERVER['HTTP_HOST'].'/error.php?message='.urlencode('Ошибка работы с базой данных'));
		}
	} else {
		header('Location: http://'.$_SERVER['HTTP_HOST'].'/error.php?message='.urlencode('Данные пропущены'));
	}
?>